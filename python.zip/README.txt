Welcome To Tetris Game!
KEYBINDS:
down arrow : To Move Blocks Quickly
up arrow : To Instantly fall block from height
left and right arrow: for moving them left and right
SPACE: for rotating blocks
Made By Ibrahim Khan 
Enjoy my game!!