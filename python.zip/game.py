import pygame
import random
pygame.init()
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
GAME_WIDTH = 10
GAME_HEIGHT = 20
PREVIEW_WIDTH = 4
PREVIEW_HEIGHT = 4
BLOCK_SIZE = 30
FPS = 3  # Adjust this this for game speed
FONT_SIZE = 36

WINDOW_SURFACE = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Tetris')

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PINK = (255, 105, 180)
PURPLE = (128, 0, 128)
AQUA = (0, 255, 255)
LIME = (0, 255, 0)
GOLD = (255, 215, 0)

SHAPES = [
    [[1, 1, 1, 1]],
    [[1, 1], [1, 1]],
    [[1, 1, 0], [0, 1, 1]],
    [[0, 1, 1], [1, 1, 0]],
    [[1, 1, 1], [0, 1, 0]],
    [[1, 1, 1], [1, 0, 0]],
    [[1, 1, 1], [0, 0, 1]]
]

SHAPE_COLORS = [CYAN, YELLOW, MAGENTA, GREEN, BLUE, ORANGE, RED, PINK, PURPLE, AQUA, LIME, GOLD]

game_grid = [[BLACK] * GAME_WIDTH for _ in range(GAME_HEIGHT)]

def draw_grid():
    for row in range(GAME_HEIGHT):
        for col in range(GAME_WIDTH):
            pygame.draw.rect(WINDOW_SURFACE, game_grid[row][col], (col * BLOCK_SIZE, row * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))
            pygame.draw.rect(WINDOW_SURFACE, WHITE, (col * BLOCK_SIZE, row * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 1)

def draw_tetromino(tetromino, tetromino_color, x, y):
    for row in range(len(tetromino)):
        for col in range(len(tetromino[row])):
            if tetromino[row][col]:
                pygame.draw.rect(WINDOW_SURFACE, tetromino_color, ((x + col) * BLOCK_SIZE, (y + row) * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))
                pygame.draw.rect(WINDOW_SURFACE, WHITE, ((x + col) * BLOCK_SIZE, (y + row) * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 1)

def check_collision(tetromino, x, y):
    for row in range(len(tetromino)):
        for col in range(len(tetromino[row])):
            if tetromino[row][col] and (x + col < 0 or x + col >= GAME_WIDTH or y + row >= GAME_HEIGHT or game_grid[y + row][x + col] != BLACK):
                return True
    return False

def clear_rows():
    full_rows = [row for row in range(GAME_HEIGHT) if all(color != BLACK for color in game_grid[row])]
    for row in full_rows:
        del game_grid[row]
        game_grid.insert(0, [BLACK] * GAME_WIDTH)
    return len(full_rows)

def draw_text(text, x, y, color=WHITE):
    font = pygame.font.Font(None, FONT_SIZE)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.center = (x, y)
    WINDOW_SURFACE.blit(text_surface, text_rect)

def game_over():
    WINDOW_SURFACE.fill(BLACK)
    draw_text('Game Over', WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2, RED)
    pygame.display.flip()
    pygame.time.wait(2000)
    pygame.quit()
    quit()

current_tetromino = random.choice(SHAPES)
current_tetromino_color = random.choice(SHAPE_COLORS)
tetromino_x = GAME_WIDTH // 2 - len(current_tetromino[0]) // 2
tetromino_y = 0

next_tetromino = random.choice(SHAPES)
next_tetromino_color = random.choice(SHAPE_COLORS)
preview_x = GAME_WIDTH + 2
preview_y = GAME_HEIGHT // 2 - PREVIEW_HEIGHT // 2

clock = pygame.time.Clock()
game_over_flag = False
move_down_flag = False
score = 0

while not game_over_flag:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                tetromino_x -= 1
                if check_collision(current_tetromino, tetromino_x, tetromino_y):
                    tetromino_x += 1
            elif event.key == pygame.K_RIGHT:
                tetromino_x += 1
                if check_collision(current_tetromino, tetromino_x, tetromino_y):
                    tetromino_x -= 1
            elif event.key == pygame.K_DOWN:
                tetromino_y += 1
                if check_collision(current_tetromino, tetromino_x, tetromino_y):
                    tetromino_y -= 1
            elif event.key == pygame.K_SPACE:
                rotated_tetromino = list(zip(*reversed(current_tetromino)))
                if not check_collision(rotated_tetromino, tetromino_x, tetromino_y):
                    current_tetromino = rotated_tetromino
            elif event.key == pygame.K_UP:
                while not check_collision(current_tetromino, tetromino_x, tetromino_y + 1):
                    tetromino_y += 1
    tetromino_y += 1
    if check_collision(current_tetromino, tetromino_x, tetromino_y):
        tetromino_y -= 1
        for row in range(len(current_tetromino)):
            for col in range(len(current_tetromino[row])):
                if current_tetromino[row][col]:
                    game_grid[tetromino_y + row][tetromino_x + col] = current_tetromino_color
        cleared_rows = clear_rows()
        score += cleared_rows * 100

        current_tetromino = next_tetromino
        current_tetromino_color = next_tetromino_color
        tetromino_x = GAME_WIDTH // 2 - len(current_tetromino[0]) // 2
        tetromino_y = 0

        next_tetromino = random.choice(SHAPES)
        next_tetromino_color = random.choice(SHAPE_COLORS)

        if check_collision(current_tetromino, tetromino_x, tetromino_y):
            game_over_flag = True

    WINDOW_SURFACE.fill(BLACK)
    draw_grid()

    draw_tetromino(current_tetromino, current_tetromino_color, tetromino_x, tetromino_y)

    draw_text('Next:', WINDOW_WIDTH - 150, 30)
    draw_tetromino(next_tetromino, next_tetromino_color, preview_x, preview_y)

    draw_text(f"Score: {score}", WINDOW_WIDTH // 2, 30)

    pygame.display.flip()
    clock.tick(FPS)

game_over()
